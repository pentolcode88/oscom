<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_model extends CI_Model {
    public function get_kop_surat() {
        return $this->db->get('kop_surat')->row_array();
    }
    
    public function get_body() {
        return [
            'body_1' => $this->db->get('body_1')->row_array(),
            'body_2' => $this->db->get('body_2')->row_array(),
            'body_3' => $this->db->get('body_3')->row_array(),
            'body_4' => $this->db->get('body_4')->row_array(),
            'body_5' => $this->db->get('body_5')->row_array(),
            'body_6' => $this->db->get('body_6')->row_array(),
            'body_7' => $this->db->get('body_7')->row_array(),
            'body_8' => $this->db->get('body_8')->row_array(),
            'body_9' => $this->db->get('body_9')->row_array(),
			'body_10' => $this->db->get('body_10')->row_array(),
			'body_11' => $this->db->get('body_11')->row_array(),
			'body_12' => $this->db->get('body_12')->row_array(),
			'body_13' => $this->db->get('body_13')->row_array(),
			'body_14' => $this->db->get('body_14')->row_array()
        ];
    }
    
    public function get_penerima_perintah() {
        return $this->db->get('penerima_perintah')->result_array();
    }
    
    public function get_penyidik() {
        return $this->db->get('penyidik')->row_array();
    }
	
    public function get_sektor() {
        return $this->db->get('sektor')->row_array();
    }
	
	public function get_tanggal() {
        return $this->db->get('tanggal')->row_array();
    }

    public function formatTanggalIndonesia($tanggal_db) {
        if (!$tanggal_db || $tanggal_db == '0000-00-00' || $tanggal_db == null) {
            return 'Tanggal tidak tersedia';
        }

        $date = DateTime::createFromFormat('Y-m-d', $tanggal_db);
        if (!$date) {
            $timestamp = strtotime($tanggal_db);
            if ($timestamp === false) {
                 return 'Format Tanggal Salah';
            }
            $date = new DateTime();
            $date->setTimestamp($timestamp);
        }

        $bulan_indonesia = [
            'January' => 'Januari', 'February' => 'Februari', 'March' => 'Maret', 'April' => 'April',
            'May' => 'Mei', 'June' => 'Juni', 'July' => 'Juli', 'August' => 'Agustus',
            'September' => 'September', 'October' => 'Oktober', 'November' => 'November', 'December' => 'Desember'
		];

		$tanggal_format = $date->format("d F Y");
		return str_replace(array_keys($bulan_indonesia), array_values($bulan_indonesia), $tanggal_format);
	}
	
	public function get_kota() {
		return $this->db->get('kota')->row_array();
	}
	
	public function get_provinsi() {
		return $this->db->get('provinsi')->row_array();
	}
	
	public function get_ttd() {
		return $this->db->get_where('ttd', ['id' => 1])->row_array();
	}

    public function get_ttd2() {
        return $this->db->get_where('ttd2', ['id' => 1])->row_array();
    }
}