<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        $this->load->database();
    }
	
    public function profile() {
        $id_user = $this->session->userdata('id_user');
        $data['user'] = $this->db->get_where('users', ['id_user' => $id_user])->row_array();
        
        $data['content_view'] = 'user/profile_view';
        $this->load->view('template/main_layout', $data);
    }

    public function change_password() {
        $data['content_view'] = 'user/change_password_view';
        $this->load->view('template/main_layout', $data);
    }
    
    public function change_username() {
        $data['content_view'] = 'user/change_username_view'; 
        $this->load->view('template/main_layout', $data);
    }

    public function upload_photo() {
        $id_user = $this->session->userdata('id_user');
        
        $config['upload_path'] = './assets/uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 1024;
        $config['file_name'] = 'user_' . $id_user . '_' . time();

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('foto_profil')) {
            $upload_data = $this->upload->data();
            $filename = $upload_data['file_name'];
            $old_foto = $this->session->userdata('foto');
            if ($old_foto && $old_foto != 'default.png' && file_exists($config['upload_path'] . $old_foto)) {
                unlink($config['upload_path'] . $old_foto);
            }

            $this->db->update('users', ['foto' => $filename], ['id_user' => $id_user]);
            $this->session->set_userdata('foto', $filename);
            $this->session->set_flashdata('message', '<div class="alert alert-success">Foto profil berhasil diupdate.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">' . $this->upload->display_errors() . '</div>');
        }
        redirect('user/profile');
    }

    public function update_password() {
        $this->form_validation->set_rules('pass_lama', 'Password Lama', 'required');
        $this->form_validation->set_rules('pass_baru', 'Password Baru', 'required|min_length[5]');
        $this->form_validation->set_rules('konf_pass', 'Konfirmasi Password', 'required|matches[pass_baru]');

        if ($this->form_validation->run() == FALSE) {
            $data['content_view'] = 'user/change_password_view';
            $this->load->view('template/main_layout', $data);
        } else {
            $id_user = $this->session->userdata('id_user');
            $pass_lama = $this->input->post('pass_lama');
            
            $user = $this->db->get_where('users', ['id_user' => $id_user])->row_array();
            if (password_verify($pass_lama, $user['password'])) {
                $pass_baru_hash = password_hash($this->input->post('pass_baru'), PASSWORD_DEFAULT);
                
                $this->db->update('users', ['password' => $pass_baru_hash], ['id_user' => $id_user]);
                $this->session->set_flashdata('message', '<div class="alert alert-success">Password berhasil diubah.</div>');
                redirect('user/change_password');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Password lama Anda salah!</div>');
                redirect('user/change_password');
            }
        }
    }
}