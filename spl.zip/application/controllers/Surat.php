<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Surat extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        
        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        
        $this->load->database();
        $this->load->model('Surat_model');
        $this->load->helper('form'); 
    }

    private function _load_surat_data() {
        $data['kop_surat'] = $this->Surat_model->get_kop_surat();
        $data['body'] = $this->Surat_model->get_body();
        $data['penerima_perintah_surat_ini'] = $this->Surat_model->get_penerima_perintah(); 
        $data['semua_personil'] = $this->db->order_by('nama', 'ASC')->get('penerima_perintah')->result_array(); 
        $data['semua_tugas'] = $this->db->order_by('id', 'ASC')->get('tugas_penyidikan')->result_array();
        $data['semua_pasal'] = $this->db->get('pasal')->result_array();
		$data['tanggal'] = $this->Surat_model->get_tanggal();
        if (isset($data['tanggal']['tanggal_dibuat'])) {
            $data['tanggal_formatted'] = $this->Surat_model->formatTanggalIndonesia($data['tanggal']['tanggal_dibuat']);
        } else {
            $data['tanggal_formatted'] = 'Tanggal tidak diatur';
        }
		$data['penyidik'] = $this->Surat_model->get_penyidik(); 
        $data['tanggal'] = $this->Surat_model->get_tanggal();
        $data['ttd'] = $this->Surat_model->get_ttd();
        $data['ttd2'] = $this->Surat_model->get_ttd2();
        $data['all_provinsi'] = $this->db->get('provinsi')->result_array();
        $data['all_kota'] = $this->db->get('kota')->result_array();
        $data['all_sektor'] = $this->db->get('sektor')->result_array(); // Ini sekarang berisi 'alamat_baris_1' & 2

        if (isset($data['tanggal']['tanggal_dibuat'])) {
            $data['tanggal']['tanggal_dibuat'] = $this->Surat_model->formatTanggalIndonesia($data['tanggal']['tanggal_dibuat']);
        }
        return $data;
    }

    /**
     * Halaman Editor Surat
     */
    public function index() {
        $data = $this->_load_surat_data();
        $data['content_view'] = 'surat_editor_view'; // Muat view editor
        $this->load->view('template/main_layout', $data); // Ke dalam layout
    }
    
    /**
     * Fungsi print() dihapus
     */
    
    /**
     * Fungsi upload
     */
    private function _do_upload($file_input_name, $table_name, $column_name) {
        $config['upload_path'] = './assets/uploads/'; 
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 1024;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($file_input_name)) {
            $this->session->set_flashdata('error', $this->upload->display_errors());
            return false;
        } else {
            $upload_data = $this->upload->data();
            $filename = $upload_data['file_name'];
            
            $cek = $this->db->get_where($table_name, ['id' => 1])->row_array();
            if ($cek) {
                if (!empty($cek[$column_name]) && file_exists($config['upload_path'] . $cek[$column_name])) {
                    unlink($config['upload_path'] . $cek[$column_name]);
                }
                $this->db->update($table_name, [$column_name => $filename], ['id' => 1]);
            } else {
                $this->db->insert($table_name, ['id' => 1, $column_name => $filename]);
            }
            return true;
        }
    }
    
    public function upload_ttd() {
        $this->_do_upload('img_ttd', 'ttd', 'img_ttd');
        redirect('surat');
    }

    public function upload_ttd2() {
        $this->_do_upload('img_ttd2', 'ttd2', 'img_ttd2');
        redirect('surat');
    }
	/**
     * Fungsi AJAX untuk menyimpan tugas baru ke database
     */
    public function ajax_tambah_tugas() {
        // Pastikan ini adalah request AJAX
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }
        
        $nama_tugas = trim($this->input->post('nama_tugas'));
        
        // Validasi input
        if (empty($nama_tugas)) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Nama tugas tidak boleh kosong.']));
            return;
        }

        // Cek duplikat
        $cek = $this->db->get_where('tugas_penyidikan', ['nama' => $nama_tugas])->row();
        if ($cek) {
             $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Tugas tersebut sudah ada di database.']));
            return;
        }
        
        // Simpan ke database
        $data = ['nama' => $nama_tugas];
        $this->db->insert('tugas_penyidikan', $data);
        $new_id = $this->db->insert_id();
        
        if ($new_id) {
            // Kirim kembali data yang baru disimpan
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true, 
                    'id' => $new_id, 
                    'nama' => $nama_tugas
                ]));
        } else {
             $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']));
        }
    }
}