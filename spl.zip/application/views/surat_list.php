<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Surat Perintah</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 11pt; }
        .surat_perintah_lidik { display: table; width: 100%; margin-top: 50px; }
        .row { display: table-row; }
        .cell { display: table-cell; vertical-align: middle; width: calc(50% - 20px); text-align: center; margin: 0 10px; }
        .under { position: relative; text-decoration: none; }
        .under::after { margin: 1pt 0 0 0; content: ''; display: block; width: 55%; height: 1px; background: black; position: absolute; left: 50%; transform: translateX(-50%); top: 2px; }
        .under1 { position: relative; text-decoration: none; margin-top: 50px;} 
        .under1::after { margin: 1pt 0 0 0; content: ''; display: block; width: 70%; height: 1px; background: black; position: absolute; left: 50%; transform: translateX(-50%); top: 2px; }
        .penerima { text-align: center; line-height: 0.1; }
        .penerima1 { text-align: center; margin-bottom: 80px; }
        .penyidik { text-align: center; line-height: 0.1; }
        .penyidik1 { text-align: center; margin-bottom: 80px; }
        .kop_gambar { text-align: center; line-height: 0; position: relative; }
        .kop_gambar img { position: absolute; top: 0; left: 50%; transform: translateX(-50%); z-index: -1; width: 75px; }
        .kop { position: relative; text-align: center; font-size: 11pt; line-height: 0; margin: 67pt 0 0 0; text-decoration: none; }
        .kop::after { content: ''; display: block; width: 33%; height: 1px; background: black; position: absolute; left: 50%; transform: translateX(-50%); top: 2px; }
        .kop_1 { position: relative; text-align: center; font-size: 11pt; line-height: 0.1; }
        .content { margin-top: 0.2px; }
        .kop_atas { font-size: 11pt; text-align: center; font-weight: bold; line-height: 0; padding: 0; margin: 10pt 0 0 0; width: 35%; }
        .kop_atas_1 { font-size: 11pt; text-align: center; font-weight: bold; line-height: 0.1; padding: 0; margin: 10pt 0 0 0; width: 35%; text-decoration: underline; }
        .justisia { font-size: 11pt; line-height: 1; }
.ttd {
    position: relative; /* Agar gambar bisa diatur relatif terhadap elemen ini */
    display: inline-block; /* Sesuaikan dengan konten */
	line-height: 0;
}

.ttd img {
	line-height: 0;
    position: absolute;
    top: -90px;
    left: 50%;
    transform: translateX(-50%);
    width: 110px;
    opacity: 0.3; /* Atur transparansi */
    z-index: -1; /* Membuat gambar berada di belakang teks */
}


        @media print {
            body {
                margin: 0;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <h2>Daftar Surat Perintah</h2>
    <a href="<?php echo site_url('surat/create'); ?>">Tambah Surat</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Isi Surat</th>
            <th>Aksi</th>
        </tr>
        <?php foreach ($surat as $row): ?>
        <tr>
            <td><?php echo $row->id; ?></td>
            <td><?php echo $row->content; ?></td>
            <td>
                <a href="<?php echo site_url('surat/edit/'.$row->id); ?>">Edit</a>
                <a href="<?php echo site_url('surat/delete/'.$row->id); ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
