<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-27 19:09:12 --> 404 Page Not Found: /index
ERROR - 2025-10-27 19:09:47 --> 404 Page Not Found: /index
ERROR - 2025-10-27 19:12:21 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:12:43 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:13:18 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:15:13 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:15:55 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:17:39 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:17:43 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:22:06 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:23:38 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:24:05 --> Severity: error --> Exception: Call to undefined function site_url() /home/cysevcog/public_html/application/views/auth/login.php 11
ERROR - 2025-10-27 19:29:13 --> 404 Page Not Found: Auth/index
ERROR - 2025-10-27 19:58:29 --> 404 Page Not Found: Faviconpng/index
ERROR - 2025-10-27 20:02:54 --> 404 Page Not Found: Js/lkk_ch.js
ERROR - 2025-10-27 20:02:55 --> 404 Page Not Found: Css/support_parent.css
ERROR - 2025-10-27 20:12:51 --> 404 Page Not Found: Js/lkk_ch.js
ERROR - 2025-10-27 20:12:51 --> 404 Page Not Found: Js/twint_ch.js
ERROR - 2025-10-27 20:53:05 --> 404 Page Not Found: Js/lkk_ch.js
ERROR - 2025-10-27 20:53:05 --> 404 Page Not Found: Css/support_parent.css
ERROR - 2025-10-27 20:53:06 --> 404 Page Not Found: Js/twint_ch.js
ERROR - 2025-10-27 21:05:10 --> Severity: Warning --> Undefined property: Auth::$db /home/cysevcog/public_html/system/core/Model.php 74
ERROR - 2025-10-27 21:05:10 --> Severity: error --> Exception: Call to a member function insert() on null /home/cysevcog/public_html/application/models/User_model.php 7
ERROR - 2025-10-27 22:36:16 --> Severity: Compile Error --> Cannot declare class Challenge, because the name is already in use /home/cysevcog/public_html/application/models/Challenge_model.php 0
ERROR - 2025-10-27 22:37:03 --> Severity: Compile Error --> Cannot declare class Challenge, because the name is already in use /home/cysevcog/public_html/application/models/Challenge_model.php 0
ERROR - 2025-10-27 22:41:04 --> 404 Page Not Found: Wordpress/index
ERROR - 2025-10-27 23:02:51 --> Severity: Compile Error --> Cannot declare class Challenge, because the name is already in use /home/cysevcog/public_html/application/models/Challenge_model.php 0
ERROR - 2025-10-27 23:02:54 --> Severity: Compile Error --> Cannot declare class Challenge, because the name is already in use /home/cysevcog/public_html/application/models/Challenge_model.php 0
