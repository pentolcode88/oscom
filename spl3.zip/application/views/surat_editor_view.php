<script>
    // Fungsi buat js drag and drop ttd
    function enableDragWithSave(id) {
        const el = document.getElementById(id);
        if (!el) return; 
        const parentContainer = el.parentElement; 
        if (!parentContainer || window.getComputedStyle(parentContainer).position !== 'relative') { return; }
        let offsetX, offsetY, isDragging = false;
        const savedTop = localStorage.getItem(id + '_top_rel'); 
        const savedLeft = localStorage.getItem(id + '_left_rel');
        if (savedTop && savedLeft) {
            el.style.position = 'absolute'; el.style.top = savedTop + 'px'; el.style.left = savedLeft + 'px'; el.style.transform = 'none'; 
        } else {
             el.style.position = 'absolute'; el.style.top = '-60px'; el.style.left = '50%'; el.style.transform = 'translateX(-50%)'; 
        }
        el.addEventListener('mousedown', function(e) { isDragging = true; const elRect = el.getBoundingClientRect(); offsetX = e.clientX - elRect.left; offsetY = e.clientY - elRect.top; el.style.zIndex = 9999; el.style.position = 'absolute'; el.style.transform = 'none'; e.preventDefault(); });
        document.addEventListener('mousemove', function(e) { if (isDragging) { const parentRect = parentContainer.getBoundingClientRect(); const x = e.clientX - parentRect.left - offsetX; const y = e.clientY - parentRect.top - offsetY; el.style.left = x + 'px'; el.style.top = y + 'px'; localStorage.setItem(id + '_top_rel', y); localStorage.setItem(id + '_left_rel', x); } });
        document.addEventListener('mouseup', function() { isDragging = false; });
    }

    // fungsi js tanggal
    function formatTanggalKeIndo(tanggal_db) {
        if (!tanggal_db) return 'Tanggal tidak diatur';
        
        // Input type="date" memberikan format YYYY-MM-DD
        const parts = tanggal_db.split('-');
        if (parts.length !== 3) return tanggal_db; // Kembalikan format asli jika salah
        
        // Buat tanggal (pastikan Waktu Universal untuk hindari masalah timezone)
        const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
        
        const bulan_indonesia = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        const tanggal = date.getUTCDate();
        const bulan = bulan_indonesia[date.getUTCMonth()];
        const tahun = date.getUTCFullYear();
        return `${tanggal} ${bulan} ${tahun}`;
    }

    // JS utama
    document.addEventListener('DOMContentLoaded', function() {
        
        enableDragWithSave('ttd');
        enableDragWithSave('ttd2');

        const tombolCetak = document.getElementById('tombolCetakBrowser');
        if(tombolCetak) { tombolCetak.addEventListener('click', function() { window.print(); }); }

        // Listener untuk dropdown 'Kepada'
        const dropdownKepada = document.getElementById('personilDropdown'); const addBtnKepada = document.getElementById('tambahPenerimaBtn'); const listKepada = document.getElementById('daftarPenerimaTerpilih');
        if (addBtnKepada && dropdownKepada && listKepada) { addBtnKepada.addEventListener('click', function() { const selectedOption = dropdownKepada.options[dropdownKepada.selectedIndex]; if (!selectedOption.value || listKepada.querySelector('li[data-id="' + selectedOption.value + '"]')) { alert(!selectedOption.value ? 'Pilih nama personil.' : selectedOption.dataset.nama + ' sudah ada.'); return; } const personilId = selectedOption.value; const nama = selectedOption.dataset.nama; const pangkat = selectedOption.dataset.pangkat; const nrp = selectedOption.dataset.nrp; const listItem = document.createElement('li'); listItem.dataset.id = personilId; listItem.innerHTML = `<div class="recipient-details"><span>Nama</span>: ${nama}<br><span>Pangkat/Nrp</span>: ${pangkat} NRP ${nrp}<span class="remove-recipient" title="Hapus">[X]</span></div><input type="hidden" name="penerima_ids[]" value="${personilId}">`; listKepada.appendChild(listItem); dropdownKepada.selectedIndex = 0; }); listKepada.addEventListener('click', function(event) { if (event.target.classList.contains('remove-recipient')) { event.target.closest('li')?.remove(); } }); }

        // Listener untuk dropdown 'Untuk'
        const dropdownUntuk = document.getElementById('tugasDropdown'); const addBtnUntuk = document.getElementById('tambahTugasBtn'); const listUntuk = document.getElementById('daftarTugasTerpilih'); const itemTerakhirStatic = listUntuk ? listUntuk.querySelector('li[data-id="static-last"]') : null; 
        if (addBtnUntuk && dropdownUntuk && listUntuk) { addBtnUntuk.addEventListener('click', function() { const selectedOption = dropdownUntuk.options[dropdownUntuk.selectedIndex]; if (!selectedOption.value || listUntuk.querySelector('li[data-id="' + selectedOption.value + '"]')) { alert(!selectedOption.value ? 'Pilih tugas.' : 'Tugas sudah ada.'); return; } const tugasId = selectedOption.value; const tugasText = selectedOption.dataset.text; const listItem = document.createElement('li'); listItem.dataset.id = tugasId; listItem.innerHTML = `${tugasText}<span class="remove-task" title="Hapus">[X]</span><input type="hidden" name="tugas_ids[]" value="${tugasId}">`; if (itemTerakhirStatic) { listUntuk.insertBefore(listItem, itemTerakhirStatic); } else { listUntuk.appendChild(listItem); } dropdownUntuk.selectedIndex = 0; }); listUntuk.addEventListener('click', function(event) { if (event.target.classList.contains('remove-task')) { const itemToRemove = event.target.closest('li'); if (itemToRemove && itemToRemove.dataset.id !== 'static-last') { itemToRemove.remove(); } } }); }
        
        // JS simpan tugas
        const tugasBaruInput = document.getElementById('tugasBaruInput'); const simpanTugasBaruBtn = document.getElementById('simpanTugasBaruBtn'); const tugasStatus = document.getElementById('tugasStatus');
        if (simpanTugasBaruBtn && tugasBaruInput && dropdownUntuk) {
            simpanTugasBaruBtn.addEventListener('click', function() {
                const namaTugas = tugasBaruInput.value.trim(); if (namaTugas === '') { alert('Nama tugas baru tidak boleh kosong.'); return; }
                tugasStatus.textContent = 'Menyimpan...';
                const formData = new FormData(); formData.append('nama_tugas', namaTugas);
                fetch('<?php echo site_url('surat/ajax_tambah_tugas'); ?>', {
                    method: 'POST', body: formData, headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const newOption = document.createElement('option'); newOption.value = data.id; newOption.dataset.text = data.nama;
                        newOption.textContent = (data.nama.length > 50 ? data.nama.substring(0, 50) + '...' : data.nama);
                        dropdownUntuk.appendChild(newOption);
                        tugasBaruInput.value = ''; tugasStatus.textContent = 'Tersimpan!'; newOption.selected = true; 
                        setTimeout(() => { tugasStatus.textContent = ''; }, 3000);
                    } else { alert('Gagal: ' + data.message); tugasStatus.textContent = 'Gagal menyimpan.'; }
                })
                .catch(error => { console.error('Error:', error); tugasStatus.textContent = 'Error koneksi.'; });
            });
        }

        // JS automatic change alamat
        const sektorSelect = document.getElementById('sektorSelect');
        const alamatSektor1 = document.getElementById('alamatSektor1');
        const alamatSektor2 = document.getElementById('alamatSektor2');
        function updateAlamat() {
            if (!sektorSelect || !alamatSektor1 || !alamatSektor2) return;
            const selectedOption = sektorSelect.options[sektorSelect.selectedIndex];
            if (selectedOption) {
                alamatSektor1.textContent = selectedOption.dataset.alamat1 || 'Alamat Baris 1...';
                alamatSektor2.textContent = selectedOption.dataset.alamat2 || 'Alamat Baris 2...';
            }
        }
        if (sektorSelect) { sektorSelect.addEventListener('change', updateAlamat); }
        updateAlamat(); 

        // JS pasal
        const pasalDropdown = document.getElementById('pasalDropdown');
        const tambahPasalBtn = document.getElementById('tambahPasalBtn');
        const pasalListDisplay = document.getElementById('daftarPasalTerpilih');
        const hiddenPasalInputs = document.getElementById('hiddenPasalInputs');
        let selectedPasal = []; 
        function renderPasalList() {
            if (hiddenPasalInputs) hiddenPasalInputs.innerHTML = ''; 
            if (!pasalListDisplay) return; 
            if (selectedPasal.length === 0) {
                // Ambil dari data PHP jika ada, sebagai default
                const defaultPasal = "<?= htmlspecialchars($body['body_11']['content'] ?? '...'); ?>";
                pasalListDisplay.innerHTML = defaultPasal; 
                return;
            }
            let parts = [];
            for (let i = 0; i < selectedPasal.length; i++) {
                const pasalText = selectedPasal[i];
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden'; hiddenInput.name = 'pasal_dipilih[]'; 
                hiddenInput.value = pasalText;
                if(hiddenPasalInputs) hiddenPasalInputs.appendChild(hiddenInput);
                const pasalSpan = document.createElement('span');
                pasalSpan.className = 'pasal-item'; 
                pasalSpan.textContent = pasalText;
                pasalSpan.title = 'Klik untuk menghapus';
                pasalSpan.dataset.pasal = pasalText;
                pasalSpan.onclick = function() {
                    selectedPasal = selectedPasal.filter(item => item !== pasalText);
                    renderPasalList();
                };
                parts.push(pasalSpan.outerHTML);
            }
            let formattedString = '';
            if (parts.length === 1) {
                formattedString = parts[0];
            } else if (parts.length === 2) {
                formattedString = parts[0] + ' dan ' + parts[1];
            } else {
                let lastItem = parts.pop();
                formattedString = parts.join(', ') + ', dan ' + lastItem;
            }
            pasalListDisplay.innerHTML = formattedString;
        }
        if (tambahPasalBtn && pasalDropdown) {
            tambahPasalBtn.addEventListener('click', function() {
                const selectedValue = pasalDropdown.value;
                if (!selectedValue) { alert('Silakan pilih pasal.'); return; }
                if (selectedPasal.includes(selectedValue)) { alert(selectedValue + ' sudah ada dalam daftar.'); return; }
                selectedPasal.push(selectedValue);
                renderPasalList();
                pasalDropdown.selectedIndex = 0;
            });
        }
        renderPasalList(); 
        
        // JS kota sektor dan ttd
        const kotaSelect = document.getElementById('kotaSelect');
        const displayKota = document.getElementById('displayKota');
        const displaySektor = document.getElementById('displaySektor');
        function updateDisplayKota() { if (kotaSelect && displayKota) { displayKota.textContent = kotaSelect.value; } }
        function updateDisplaySektor() { if (sektorSelect && displaySektor) { displaySektor.textContent = sektorSelect.value; } }
        if (kotaSelect) { kotaSelect.addEventListener('change', updateDisplayKota); }
        if (sektorSelect) { sektorSelect.addEventListener('change', updateDisplaySektor); }
        updateDisplayKota(); updateDisplaySektor();
        
        // JS tanggal
        const tanggalInput = document.getElementById('tanggalInput');
        const tanggalDisplay = document.getElementById('tanggalDisplay');

        if (tanggalInput && tanggalDisplay) {
            // 1. Saat teks (span) diklik, panggil kalender (input)
            tanggalDisplay.addEventListener('click', function() {
                try {
                    tanggalInput.showPicker();
                } catch (error) {
                    // Fallback untuk browser lama
                    tanggalInput.click();
                }
            });

            // 2. Saat tanggal di kalender berubah, update teks (span)
            tanggalInput.addEventListener('change', function() {
                tanggalDisplay.textContent = formatTanggalKeIndo(this.value);
            });
        }
        
    });
</script>

<div class="a4-frame">
    <div class="kop_atas">
        <p>
            <?= $kop_surat['content'] ?> 
            <select id="provinsiSelect" name="provinsi_dropdown">
                <?php foreach ($all_provinsi as $prov): ?>
                    <option value="<?= $prov['nm_provinsi']; ?>" <?= ($prov['nm_provinsi'] == $kop_surat['provinsi']) ? 'selected' : ''; ?>>
                        <?= $prov['nm_provinsi']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p style="margin-right: 10px;">
            <?= $kop_surat['content_1'] ?> 
             <select id="kotaSelect" name="kota_dropdown">
                <?php foreach ($all_kota as $kota): ?>
                    <option value="<?= $kota['nm_kota']; ?>" <?= ($kota['nm_kota'] == $kop_surat['kota']) ? 'selected' : ''; ?>>
                        <?= $kota['nm_kota']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p style="margin-left: 35px;">
            <?= $kop_surat['content_2'] ?> 
            <select id="sektorSelect" name="sektor_dropdown">
                 <?php foreach ($all_sektor as $sektor): ?>
                    <option value="<?= $sektor['nm_sektor']; ?>" 
                            data-alamat1="<?= htmlspecialchars($sektor['alamat_baris_1'] ?? ''); ?>"
                            data-alamat2="<?= htmlspecialchars($sektor['alamat_baris_2'] ?? ''); ?>"
                            <?= ($sektor['nm_sektor'] == $kop_surat['sektor']) ? 'selected' : ''; ?>>
                        <?= $sektor['nm_sektor']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
    </div>
    <p class="kop_atas_1" id="alamatSektor1"></p>
    <p class="kop_atas_1" id="alamatSektor2"></p>
    <div class="justisia"><p>*<?= $kop_surat['content_4']; ?>*</p></div>
    <p class="kop_gambar"><img src="<?= base_url('assets/uploads/' . ($kop_surat['kop_gambar1'] ?? 'default_logo.png')); ?>" width="150"></p>

    <p style="text-align: center; font-size: 11pt; line-height: 0; margin: -5pt 0 0 0;"><?= $kop_surat['kop_1']; ?></p>
    <div class="underline kop-line"></div>
    <p class="kop_1"><?= $kop_surat['content_5'] . '/' . $kop_surat['no_surat'] . '/' . $kop_surat['no_romawi'] . '/' . $kop_surat['tahun'] . '/' . $kop_surat['nm_satuan'] ; ?></p>
    
    <table class="surat-middle-section">
         <tr> <td class="label-col"><?= $body['body_1']['content'] ?? 'Pertimbangan'; ?></td><td class="colon-col">:</td> <td class="content-col"><?= $body['body_10']['content'] ?? '...'; ?></td> </tr>
         <tr> 
            <td class="label-col"><?= $body['body_2']['content'] ?? 'Dasar'; ?></td><td class="colon-col">:</td> 
            <td class="content-col"> 
                <div class="pasal-selector" style="margin-bottom: 10px;">
                    <select id="pasalDropdown" style="padding: 5px; min-width: 200px;"><option value="">-- Pilih Pasal --</option><?php foreach ($semua_pasal as $pasal): ?><option value="<?= htmlspecialchars($pasal['nama_pasal']); ?>"><?= $pasal['nama_pasal']; ?></option><?php endforeach; ?></select>
                    <button type="button" id="tambahPasalBtn" class="btn btn-sm" style="padding: 5px 10px; font-size: 0.9em; margin-left: 5px;">Tambah</button>
                </div>
                <div id="daftarPasalTerpilih" style="line-height: 1.6;">
                    </div>
                <div id="hiddenPasalInputs"></div>
            </td> 
         </tr>
         <tr><td colspan="3" style="text-align: center; font-weight: bold; padding: 10px 0 5px;">DIPERINTAHKAN</td></tr>
         <tr> <td class="label-col"><?= $body['body_3']['content'] ?? 'Kepada'; ?></td><td class="colon-col">:</td> <td class="content-col"> <div class="recipient-selector" style="margin-bottom: 0px;"> <select id="personilDropdown" style="padding: 5px; min-width: 200px;"><option value="">-- Pilih Nama --</option><?php foreach ($semua_personil as $p): ?><option value="<?= $p['id']; ?>" data-nama="<?= htmlspecialchars($p['nama']); ?>" data-pangkat="<?= htmlspecialchars($p['pangkat']); ?>" data-nrp="<?= htmlspecialchars($p['nrp']); ?>"><?= $p['nama']; ?> (<?= $p['nrp']; ?>)</option><?php endforeach; ?></select> <button type="button" id="tambahPenerimaBtn" class="btn btn-sm" style="padding: 5px 10px; font-size: 0.9em; margin-left: 5px;">Tambah</button> </div> <ol id="daftarPenerimaTerpilih" style="padding-left: 20px; margin: 0;"><?php if (!empty($penerima_perintah_surat_ini)): ?><?php foreach ($penerima_perintah_surat_ini as $p): ?><li data-id="<?= $p['id']; ?>"><div class="recipient-details"><span>Nama</span>: <?= $p['nama'] ?? 'N/A'; ?><br><span>Pangkat/Nrp</span>: <?= $p['pangkat'] ?? 'N/A'; ?> NRP <?= $p['nrp'] ?? 'N/A'; ?><span class="remove-recipient" title="Hapus">[X]</span></div><input type="hidden" name="penerima_ids[]" value="<?= $p['id']; ?>"></li><?php endforeach; ?><?php endif; ?></ol> </td> </tr>
         <tr> <td class="label-col"><?= $body['body_4']['content'] ?? 'Untuk'; ?></td><td class="colon-col">:</td> <td class="content-col"> <div class="task-selector" style="margin-bottom: 10px;"> <div style="display: flex; margin-bottom: 5px;"><input type="text" id="tugasBaruInput" placeholder="Input tugas baru..." style="flex-grow: 1; padding: 5px; border: 1px solid #ccc; border-radius: 4px;"><button type="button" id="simpanTugasBaruBtn" class="btn btn-sm" style="padding: 5px 10px; font-size: 0.9em; margin-left: 5px; flex-shrink: 0;">Simpan</button></div> <span id="tugasStatus" style="font-size: 0.8em; color: green; display: block; height: 1em; margin-bottom: 5px;"></span> <select id="tugasDropdown" style="padding: 5px; width: 100%; box-sizing: border-box; margin-bottom: 5px;"><option value="">-- Pilih Tugas Tersimpan --</option><?php foreach ($semua_tugas as $t): ?><option value="<?= $t['id']; ?>" data-text="<?= htmlspecialchars($t['nama']); ?>"><?= substr($t['nama'], 0, 50) . (strlen($t['nama']) > 50 ? '...' : ''); ?></option><?php endforeach; ?></select> <button type="button" id="tambahTugasBtn" class="btn btn-sm" style="padding: 5px 10px; font-size: 0.9em;">Tambah dari Dropdown</button> </div> <ol id="daftarTugasTerpilih" style="padding-left: 20px; margin: 0;"></ol> </td> </tr>
         <tr> <td class="label-col"><?= $body['body_14']['content'] ?? 'Selesai'; ?></td><td class="colon-col">.</td><td class="content-col"></td> </tr>
    </table>
    
    <div class="surat_perintah_lidik">
        <div class="row">
            <div class="cell penerima">
                <p class="penerima1"><?= $body['body_5']['content'] ?? 'Yang Menerima Perintah,'; ?></p>
                <p class="ttd"><img id="ttd" class="draggable-ttd" src="<?= base_url('assets/uploads/' . ($ttd['img_ttd'] ?? 'default_ttd.png')); ?>" width="150"></p>
                <p style="line-height: 0; margin: 20pt 0 0 0;"><strong><?= $penerima_perintah_surat_ini[0]['nama'] ?? 'Nama Penerima'; ?></strong></p> 
                <div class="underline under1-line"></div>
                <p style="line-height: 0.1; margin-top: 5px;"><?= $penerima_perintah_surat_ini[0]['pangkat'] ?? 'Pangkat'; ?> NRP <?= $penerima_perintah_surat_ini[0]['nrp'] ?? 'NRP'; ?></p>
                <form action="<?= site_url('surat/upload_ttd'); ?>" method="post" enctype="multipart/form-data" style="margin: 20px 0;"><label for="img_ttd">Upload Tanda Tangan:</label><input type="file" name="img_ttd" accept="image/*" required><button type="submit" class="btn">Upload</button></form>
            </div>
            <div class="cell penyidik">
                <p><?= $body['body_6']['content'] ?? 'Dikeluarkan di'; ?> : <span id="displayKota"><?= $kop_surat['kota'] ?? 'Kota'; ?></span></p>
                
                <p>
                    <?= $body['body_7']['content'] ?? 'Pada Tanggal'; ?> : 
                    <input type="date" id="tanggalInput" value="<?= $tanggal['tanggal_dibuat'] ?? ''; ?>" style="display: none;">
                    <span id="tanggalDisplay" class="clickable-date">
                        <?= $tanggal_formatted ?? 'Tanggal'; ?>
                    </span>
                </p>
                <p><?= $body['body_8']['content'] ?? 'Jabatan'; ?> <span id="displaySektor"><?= $kop_surat['sektor'] ?? 'Sektor'; ?></span></p>
                <p class="penyidik1"><?= $body['body_9']['content'] ?? 'Selaku Penyidik'; ?></p>
                <p class="ttd1"><img id="ttd2" class="draggable-ttd" src="<?= base_url('assets/uploads/' . ($ttd2['img_ttd2'] ?? 'default_ttd.png')); ?>" width="150"></p>
                <p style="line-height: 0; margin: -80pt 0 0 0;"><strong><?= $penyidik['nama_penyidik'] ?? 'Nama Penyidik'; ?></strong></p> 
                <div class="underline under-line"></div>
                <p style="line-height: 0.1; margin-top: 5px;"><?= $penyidik['pangkat'] ?? 'Pangkat'; ?> NRP <?= $penyidik['nrp'] ?? 'NRP'; ?></p>
                <form action="<?= site_url('surat/upload_ttd2'); ?>" method="post" enctype="multipart/form-data" style="margin: 0px 0;"><label for="img_ttd2">Upload Tanda Tangan:</label><input type="file" name="img_ttd2" accept="image/*" required><button type="submit" class="btn">Upload</button></form>
            </div>
        </div>
    </div>

    <div class="print-button">
        <button type="button" id="tombolCetakBrowser" class="btn">Cetak Surat</button>
    </div>
</div>