<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi Surat</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            display: grid;
            place-items: center;
        }
        
        .login-container {
            background: #fff;
            padding: 30px 35px;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            width: 350px;
            box-sizing: border-box;
            text-align: center;
        }

        .login-logo {
            width: 100px;
            margin-bottom: 20px;
        }

        h2 {
            margin-top: 0;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
        }
        
        .form-group {
            margin-bottom: 20px;
            text-align: left; /* Ratakan kiri label & input */
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 0.9em;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            transition: all 0.2s ease;
        }

        .form-group input:focus {
            border-color: #2a5298;
            box-shadow: 0 0 5px rgba(42,82,152,0.3);
            outline: none;
        }
        
        .error {
            color: #d93025;
            font-size: 0.9em;
            margin-top: 5px;
            text-align: left;
        }
        
        .btn {
            background: #3498db;
            color: white;
            padding: 12px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 1em;
            font-weight: 600;
            transition: background 0.2s ease;
        }

        .btn:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    
    <div class="login-container">
        
        <img src="<?php echo base_url('assets/img/logo.png'); ?>" alt="Logo Aplikasi" class="login-logo">

        <h2>Login Editor Sprint Sidik</h2>
        
        <?php echo form_open('auth/login_action'); ?>
            
            <?php if (isset($error)): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" value="<?php echo set_value('username'); ?>" autofocus>
                <div class="error"><?php echo form_error('username'); ?></div>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password">
                <div class="error"><?php echo form_error('password'); ?></div>
            </div>
            
            <button type="submit" class="btn">Masuk</button>
            
        <?php echo form_close(); ?>
    </div>

</body>
</html>