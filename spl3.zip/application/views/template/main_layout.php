<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Editor Sprint</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

    <div class="layout-container">
        
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="<?php echo base_url('assets/img/logo.png'); ?>" alt="Logo">
                <h3>Aplikasi Editor Sprint</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<?php echo site_url('surat'); ?>">Editor Sprint Sidik</a></li>
                <li><a href="<?php echo site_url('user/profile'); ?>">Profil Saya</a></li>
                <li><a href="<?php echo site_url('user/change_password'); ?>">Ubah Password</a></li>
                <li><a href="<?php echo site_url('auth/logout'); ?>">Logout</a></li>
            </ul>
        </aside>

        <div class="main-wrapper">
            
            <header class="header">
                <div class="user-menu">
                    <div class="user-menu-trigger">
                        <img src="<?php echo base_url('assets/uploads/' . $this->session->userdata('foto')); ?>" alt="Foto Profil">
                        <span><?php echo $this->session->userdata('nama_lengkap'); ?></span>
                    </div>
                    
                    <div class="user-menu-dropdown">
                        <div class="dropdown-header">
                            <h5><?php echo $this->session->userdata('nama_lengkap'); ?></h5>
                            <p><?php echo $this->session->userdata('username'); ?></p>
                        </div>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo site_url('user/profile'); ?>">Profil Saya</a></li>
                            <li><a href="<?php echo site_url('user/change_password'); ?>">Ubah Password</a></li>
                            <li><a href="<?php echo site_url('user/change_username'); ?>">Ubah Username</a></li>
                            <li class="dropdown-divider"></li>
                            <li><a href="<?php echo site_url('auth/logout'); ?>">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <main class="content-area">
                
                <?php $this->load->view($content_view); ?>
                
            </main>

            <footer class="footer">
                &copy; <?php echo date('Y'); ?> Aplikasi Editor Sprint. Created by Muhamad Hasan Sarofi.
            </footer>
        </div>
    </div>

</body>
</html>