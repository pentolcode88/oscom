﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Print Surat Perintah Lidik</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 11pt;
            margin: 0;
            padding: 0;
        }

        .surat_perintah_lidik { display: table; width: 100%; margin-top: 50px; margin: 0 10px; }
        .row { display: table-row; }
        .cell { display: table-cell; vertical-align: middle; width: calc(50% - 20px); text-align: center; }

        .under, .under1 {
            position: relative;
            text-decoration: none;
        }
        .under { margin-top: -20px; }
        .under::after {
            content: ''; display: block; width: 55%; height: 1px; background: black;
            position: absolute; left: 50%; transform: translateX(-50%); top: 2px;
        }
        .under1 { margin-top: 100px; }
        .under1::after {
            content: ''; display: block; width: 70%; height: 1px; background: black;
            position: absolute; left: 50%; transform: translateX(-50%); top: 2px;
        }

        .penerima, .penyidik { text-align: center; line-height: 0.1; }
        .penerima1 { margin-bottom: -15px; line-height: 0.1;}
        .penyidik1 { margin-bottom: 80px; line-height: 0.1;}

        .kop_gambar { text-align: center; line-height: 0; position: relative; }
        .kop_gambar img {
            position: absolute; top: 0; left: 50%; transform: translateX(-50%);
            z-index: -1; width: 75px;
        }

        .kop, .kop_1, .kop_atas, .kop_atas_1 { text-align: center; }
        .kop { font-size: 11pt; line-height: 0; margin: 67pt 0 0 0; position: relative; }
        .kop::after {
            content: ''; display: block; width: 33%; height: 1px; background: black;
            position: absolute; left: 50%; transform: translateX(-50%); top: 2px;
        }
        .kop_1 { font-size: 11pt; line-height: 0.1; }
        .kop_atas {
            font-size: 11pt; font-weight: bold; line-height: 0;
            padding: 0; margin: 10pt 0 0 0; width: 35%;
        }
        .kop_atas_1 {
            font-size: 11pt; font-weight: bold; line-height: 0.1;
            padding: 0; margin: 10pt 0 0 0; width: 35%;
            text-decoration: underline;
        }

        .justisia { font-size: 11pt; line-height: 1; }

        .ttd-wrapper {
            position: relative;
            width: 100%;
            display: inline-block;
            line-height: 0;
        }

        .ttd-wrapper img {
            position: absolute;
            width: 210px;
            z-index: 1;
        }

        @media print {
            body {
                margin: 0;
                padding: 0;
            }
        }
    </style>
    <script>
        window.onload = function() {
            window.print();
            setTimeout(function() {
                window.close();
            }, 1000);
        };
    </script>
</head>
<body>
    <div class="kop_atas">
        <p><?= $kop_surat['content'] . ' ' . $provinsi['nm_provinsi']; ?></p>
        <p><?= $kop_surat['content_1'] . ' ' . $kop_surat['kota']; ?></p>
        <p><?= $kop_surat['content_2'] . ' ' . $kop_surat['sektor']; ?></p>
    </div>
    <p class="kop_atas_1"><?= $kop_surat['content_3']; ?></p>
    <p class="kop_atas_1"><?= $kop_surat['content_6']; ?></p>
    <div class="justisia">
        <p>*<?= $kop_surat['content_4']; ?>*</p>
    </div>
    <p class="kop_gambar">
        <img src="<?= FCPATH . 'assets/uploads/' . $kop_surat['kop_gambar1']; ?>" width="150">
    </p>
    <p class="kop"><?= $kop_surat['kop_1']; ?></p>
    <p class="kop_1"><?= $kop_surat['content_5'] . '/' . $kop_surat['no_surat'] . '/' . $kop_surat['no_romawi'] . '/' . $kop_surat['tahun'] . '/' . $kop_surat['nm_satuan']; ?></p>

    <div class="content">
        <p><?= $body['body_1']['content'] . ' : ' . $body['body_10']['content']; ?></p>
        <p><?= $body['body_2']['content'] . ' : ' . $body['body_11']['content']; ?></p>
        <p><?= $body['body_3']['content'] . ' : ' . $body['body_12']['content']; ?></p>
        <p><?= $body['body_4']['content'] . ' : ' . $body['body_13']['content']; ?></p>
        <p><?= $body['body_14']['content']; ?></p>
    </div>

    <div class="surat_perintah_lidik">
        <div class="row">
            <div class="cell penerima">
                <p class="penerima1"><?= $body['body_5']['content']; ?></p>
                <div class="ttd-wrapper">
                    <img id="ttd"
                         src="<?= FCPATH . 'assets/uploads/' . $ttd['img_ttd']; ?>"
                         style="<?= ($ttd_top && $ttd_left) ? "top:{$ttd_top}cm;left:{$ttd_left}cm;" : '' ?>">
                </div>
                <p class="under1"><strong><?= $penerima_perintah['nama']; ?></strong></p>
                <p><?= $penerima_perintah['pangkat']; ?> NRP <?= $penerima_perintah['nrp']; ?></p>
            </div>

            <div class="cell penyidik">
                <p><?= $body['body_6']['content'] . ' : ' . $kota['nm_kota']; ?></p>
                <p><?= $body['body_7']['content'] . ' : ' . $tanggal['tanggal_dibuat']; ?></p>
                <p><?= $body['body_8']['content'] . ' ' . $sektor['nm_sektor']; ?></p>
                <p class="penyidik1"><?= $body['body_9']['content']; ?></p>
                <div class="ttd-wrapper">
                    <img id="ttd2"
                         src="<?= FCPATH . 'assets/uploads/' . $ttd2['img_ttd2']; ?>"
                         style="<?= ($ttd2_top && $ttd2_left) ? "top:{$ttd2_top}cm;left:{$ttd2_left}cm;" : '' ?>">
                </div>
                <p class="under"><strong><?= $penerima_perintah['nama']; ?></strong></p>
                <p><?= $penerima_perintah['pangkat']; ?> NRP <?= $penerima_perintah['nrp']; ?></p>
            </div>
        </div>
    </div>
</body>
</html>
