<h3>Ubah Password</h3>
<p>Pastikan Anda menggunakan password yang kuat.</p>

<?php echo $this->session->flashdata('message'); ?>

<div class="form-container">
    <?php echo form_open('user/update_password'); ?>
        <div class="form-group">
            <label for="pass_lama">Password Lama</label>
            <input type="password" name="pass_lama" required>
            <div style="color:red;"><?php echo form_error('pass_lama'); ?></div>
        </div>
        <div class="form-group">
            <label for="pass_baru">Password Baru</label>
            <input type="password" name="pass_baru" required>
            <div style="color:red;"><?php echo form_error('pass_baru'); ?></div>
        </div>
        <div class="form-group">
            <label for="konf_pass">Konfirmasi Password Baru</label>
            <input type="password" name="konf_pass" required>
            <div style="color:red;"><?php echo form_error('konf_pass'); ?></div>
        </div>
        <button type="submit" class="btn">Update Password</button>
    <?php echo form_close(); ?>
</div>