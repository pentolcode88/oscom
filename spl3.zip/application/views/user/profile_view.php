<h3>Profil Saya</h3>
<p>Kelola informasi profil Anda di sini.</p>

<?php echo $this->session->flashdata('message'); ?>

<div class="form-container">
    <h4>Biodata</h4>
    <div class="form-group">
        <label>Nama Lengkap</label>
        <input type="text" value="<?php echo $user['nama_lengkap']; ?>" readonly>
    </div>
    <div class="form-group">
        <label>Username</label>
        <input type="text" value="<?php echo $user['username']; ?>" readonly>
    </div>

    <hr style="margin: 20px 0;">
    
    <h4>Ubah Foto Profil</h4>
    <img src="<?php echo base_url('assets/uploads/' . $user['foto']); ?>" alt="Foto Profil" style="width: 100px; height: 100px; border-radius: 50%; margin-bottom: 15px;">
    
    <?php echo form_open_multipart('user/upload_photo'); ?>
        <div class="form-group">
            <label for="foto_profil">Pilih foto baru (JPG/PNG, maks 1MB)</label>
            <input type="file" name="foto_profil" required>
        </div>
        <button type="submit" class="btn">Upload Foto</button>
    <?php echo form_close(); ?>
</div>